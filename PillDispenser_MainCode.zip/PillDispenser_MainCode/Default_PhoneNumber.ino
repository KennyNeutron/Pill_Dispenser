// Global variable for phone number with a default value
String phoneNumber = "+639765624995";  // Set default recipient number